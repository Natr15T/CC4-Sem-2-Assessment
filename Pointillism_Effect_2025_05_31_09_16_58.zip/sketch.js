let img;

function preload() {
  // Load your image
  img = loadImage('Decolorization.jpg');
}

function setup() {
  createCanvas(900, 450);
  background(255);
  img.resize(width, height);
  noStroke();
  frameRate(2000); // Speed up dot drawing
}

function draw() {
  // Choose a random location
  let x = floor(random(img.width));
  let y = floor(random(img.height));

  // Get the color at that location
  let c = img.get(x, y);

  // Use that color to draw a small circle
  fill(c);
  let dotSize = random(4, 8);
  ellipse(x, y, dotSize, dotSize);
}
