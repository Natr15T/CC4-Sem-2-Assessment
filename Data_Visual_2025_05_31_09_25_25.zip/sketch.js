let data = [25, 40, 10, 60, 80, 55, 30];

function setup() {
  createCanvas(400, 300);
  background(240);
  noStroke();
  fill(100, 150, 255);

  let barWidth = width / data.length;

  for (let i = 0; i < data.length; i++) {
    let barHeight = map(data[i], 0, 100, 0, height);
    rect(i * barWidth, height - barHeight, barWidth - 10, barHeight);
  }
}
