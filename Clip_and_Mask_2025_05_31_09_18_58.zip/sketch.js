let img;
function preload(){
  img=loadImage("colorization.jpg");
}
function setup() {

  createCanvas(500, 500);
  imageMode(CENTER);
}

function draw() {
  background(190,220,250);
    img.resize(450,450)
  
    let mask1=createGraphics(450,450);
    mask1.circle(225,225,400);
    mask1.triangle(0,0,225,450,450,0);
  
    img.mask(mask1);
    image(img,width / 2, height / 2);
}