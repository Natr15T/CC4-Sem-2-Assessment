let fft;
let particles = [];
let mode = "radial"; // Start in radial mode
let margin = 50; // Margin for linear waveform

function preload() {
  
  MySound = loadSound("Assumptions.mp3")
  
}

function setup() {
  createCanvas(500, 500);
  fft = new p5.FFT();
  MySound.setVolume(1);
  MySound.loop();
}

function draw() {
  background(0, 50);
  if (!MySound.isPlaying()) return;
  drawStars(5);
  let waveform = fft.waveform();
  noFill();
  stroke(255);
  strokeWeight(2);

  if (mode === "radial") {
    translate(width / 2, height / 2);
    beginShape();
    for (let i = 0; i < waveform.length; i++) {
      let angle = map(i, 0, waveform.length, 0, TWO_PI);
      let r = map(waveform[i], -1, 1, 100, 200);
      let x = r * cos(angle);
      let y = r * sin(angle);
      vertex(x, y);
    }
    endShape(CLOSE);
  } else if (mode === "linear") {
    // Draw linear waveform like the image
    beginShape();
    for (let i = 0; i < waveform.length; i++) {
      let x = map(i, 0, waveform.length, margin, width - margin);
      let y = map(waveform[i], -1, 1, height - margin, margin);
      vertex(x, y);
    }
    endShape();
  }

  // --- Particle Visualizer ---
  let spectrum = fft.analyze();
  let energy = fft.getEnergy("bass");

  if (energy > 180 && mode === "radial") { // Only in radial mode
    for (let i = 0; i < 5; i++) {
      particles.push(new Particle());
    }
  }

  if (mode === "radial") {
    for (let i = particles.length - 1; i >= 0; i--) {
      particles[i].update();
      particles[i].show();
      if (particles[i].finished()) {
        particles.splice(i, 1);
      }
    }
  }
}

// --- Toggle Play/Pause on Click ---
function mousePressed() {
  if (MySound.isPlaying()) {
    MySound.pause();
  } else {
    MySound.loop();
  }
}

// --- Toggle Mode on L Press ---
function keyPressed() {
  if (key === 'L' || key === 'l') {
    mode = (mode === "radial") ? "linear" : "radial";
  }
}

// --- Particle Class ---
class Particle {
  constructor() {
    this.pos = createVector(0, 0);
    this.vel = p5.Vector.random2D().mult(random(1, 5));
    this.lifetime = 255;
  }

  update() {
    this.pos.add(this.vel);
    this.lifetime -= 4;
  }

  finished() {
    return this.lifetime < 0;
  }

  show() {
    noStroke();
    fill(255, this.lifetime);
    ellipse(this.pos.x, this.pos.y, 8);
  }
}

//Function to draw the stars
function drawStars(numStars) {
  fill(255);
  for (let i = 0; i < numStars; i++) {
    let x = random(width);
    let y = random(height);
    ellipse(x, y, random(1, 5));
  }
}