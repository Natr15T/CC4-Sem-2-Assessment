let trail = [];  // Array to hold the trail data

function setup() {
  createCanvas(600, 400);
  colorMode(HSB, 360, 100, 100);
  noFill();
}

function draw() {
  background(255, 10);  // Slight transparency to create a fading effect

  // Add the current mouse position and color to the trail
  let trailItem = {
    x: mouseX,
    y: mouseY,
    color: color((frameCount * 2) % 360, 100, 100),  // Color changes over time
    size: random(10, 30),  // Random size for dynamic effect
    alpha: 100  // Start with full opacity
  };

  trail.push(trailItem);  // Add new trail item to the array

  // Loop through the trail array and draw each trail item
  for (let i = 0; i < trail.length; i++) {
    let t = trail[i];

    // Set the color and opacity for each trail item
    stroke(t.color.levels[0], t.color.levels[1], t.color.levels[2], t.alpha);
    strokeWeight(t.size);

    // Draw the trail item (ellipse)
    ellipse(t.x, t.y, t.size, t.size);

    // Fade out the trail by decreasing its opacity
    t.alpha -= 2;  // Decrease alpha to fade the trail

    // Remove the trail item from the array if it's completely faded
    if (t.alpha <= 0) {
      trail.splice(i, 1);  // Remove the item from the trail array
      i--;  // Adjust the index after removal
    }
  }
}
