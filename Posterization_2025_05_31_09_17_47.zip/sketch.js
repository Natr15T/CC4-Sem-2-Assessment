let img;

function preload() {
  // Load an image (you can also upload your own in the p5 editor)
  img = loadImage('colorization.jpg');
}

function setup() {
  createCanvas(400, 400);
  image(img, 0, 0, width, height);
  img.loadPixels();

  // Loop through every pixel
  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      let index = (x + y * img.width) * 4;
      let r = img.pixels[index + 0];
      let g = img.pixels[index + 1];
      let b = img.pixels[index + 2];

      // Invert color
      img.pixels[index + 0] = 255 - r;
      img.pixels[index + 1] = 255 - g;
      img.pixels[index + 2] = 255 - b;
    }
  }

  img.updatePixels();
  image(img, 0, 0, width, height);
}
