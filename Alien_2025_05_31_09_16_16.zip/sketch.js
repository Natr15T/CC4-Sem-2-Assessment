function setup() {
  createCanvas(400, 400);
  background(30);
  noStroke();
}

function draw() {
  background(30);

  // Body
  fill(100, 255, 100);
  ellipse(width/2, height/2 + 50, 100, 150);

  // Head
  ellipse(width/2, height/2 - 50, 120, 120);

  // Eyes
  fill(255);
  ellipse(width/2 - 25, height/2 - 60, 30, 40);
  ellipse(width/2 + 25, height/2 - 60, 30, 40);
  fill(0);
  ellipse(width/2 - 25, height/2 - 60, 10, 15);
  ellipse(width/2 + 25, height/2 - 60, 10, 15);

  // Antennae
  stroke(100, 255, 100);
  strokeWeight(4);
  line(width/2 - 30, height/2 - 100, width/2 - 50, height/2 - 130);
  line(width/2 + 30, height/2 - 100, width/2 + 50, height/2 - 130);

  // Antenna ends
  noStroke();
  fill(255, 0, 200);
  ellipse(width/2 - 50, height/2 - 130, 10, 10);
  ellipse(width/2 + 50, height/2 - 130, 10, 10);

  noLoop(); // Stop draw loop since this is a static scene
}
