let MySound;
let fft;
let particles = [];

function preload() {
  MySound = loadSound("FeelingIt.mp3");
}

function setup() {
  createCanvas(500, 500);
  fft = new p5.FFT();
  MySound.setVolume(1);
  MySound.loop();
}

function draw() {
  background(0, 50); // Semi-transparent for trail effect
  translate(width / 2, height / 2);

  if (!MySound.isPlaying()) return; // Stop visuals when paused

  // --- Radial Waveform ---
  let waveform = fft.waveform();
  noFill();
  stroke(255);
  strokeWeight(2);
  beginShape();
  for (let i = 0; i < waveform.length; i++) {
    let angle = map(i, 0, waveform.length, 0, TWO_PI);
    let r = map(waveform[i], -1, 1, 100, 200);
    let x = r * cos(angle);
    let y = r * sin(angle);
    vertex(x, y);
  }
  endShape(CLOSE);

  // --- Particle Visualizer ---
  let spectrum = fft.analyze();
  let energy = fft.getEnergy("bass");

  if (energy > 180) {
    for (let i = 0; i < 5; i++) {
      particles.push(new Particle());
    }
  }

  for (let i = particles.length - 1; i >= 0; i--) {
    particles[i].update();
    particles[i].show();
    if (particles[i].finished()) {
      particles.splice(i, 1);
    }
  }
}

// --- Mouse Toggle for Play/Pause ---
function mousePressed() {
  if (MySound.isPlaying()) {
    MySound.pause();
  } else {
    MySound.loop();
  }
}

// --- Particle Class ---
class Particle {
  constructor() {
    this.pos = createVector(0, 0);
    this.vel = p5.Vector.random2D().mult(random(1, 5));
    this.lifetime = 255;
  }

  update() {
    this.pos.add(this.vel);
    this.lifetime -= 4;
  }

  finished() {
    return this.lifetime < 0;
  }

  show() {
    noStroke();
    fill(255, this.lifetime);
    ellipse(this.pos.x, this.pos.y, 8);
  }
}

