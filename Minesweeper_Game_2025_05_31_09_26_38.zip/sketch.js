let grid;
let cols, rows;
let w = 40;
let totalMines = 10;
let gameOver = false;
let tryAgainBtn;

function setup() {
  createCanvas(400, 450); // Extra space for Game Over text and button
  cols = floor(width / w);
  rows = floor(400 / w);
  resetGame();
}

function draw() {
  background(255);

  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      grid[i][j].show();
    }
  }

  if (gameOver) {
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER);
    text("Game Over", width / 2, 420);
  }
}

function mousePressed() {
  if (gameOver) return;

  let i = floor(mouseX / w);
  let j = floor(mouseY / w);
  if (i < 0 || j < 0 || i >= cols || j >= rows) return;

  if (mouseButton === RIGHT || keyIsDown(CONTROL)) {
    grid[i][j].toggleFlag();
    return false;
  }

  if (!grid[i][j].flagged) {
    grid[i][j].reveal();
    if (grid[i][j].mine) {
      gameOver = true;
      revealAll();
    }
  }
  return false;
}

function make2DArray(cols, rows) {
  let arr = new Array(cols);
  for (let i = 0; i < cols; i++) {
    arr[i] = new Array(rows);
  }
  return arr;
}

function resetGame() {
  grid = make2DArray(cols, rows);
  gameOver = false;

  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      grid[i][j] = new Cell(i, j, w);
    }
  }

  // Place mines
  let options = [];
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      options.push([i, j]);
    }
  }

  for (let n = 0; n < totalMines; n++) {
    let index = floor(random(options.length));
    let choice = options.splice(index, 1)[0];
    let i = choice[0];
    let j = choice[1];
    grid[i][j].mine = true;
  }

  // Count neighboring mines
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      grid[i][j].countMines();
    }
  }
}

function revealAll() {
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      grid[i][j].revealed = true;
    }
  }
}

function mouseReleased() {
  if (gameOver && mouseX > width / 2 - 60 && mouseX < width / 2 + 60 && mouseY > 430 && mouseY < 460) {
    resetGame();
  }
}

class Cell {
  constructor(i, j, w) {
    this.i = i;
    this.j = j;
    this.x = i * w;
    this.y = j * w;
    this.w = w;
    this.mine = false;
    this.revealed = false;
    this.neighborCount = 0;
    this.flagged = false;
  }

  show() {
    stroke(0);
    noFill();
    rect(this.x, this.y, this.w, this.w);

    if (this.revealed) {
      if (this.mine) {
        fill(127);
        ellipse(this.x + this.w / 2, this.y + this.w / 2, this.w * 0.5);
      } else {
        fill(200);
        rect(this.x, this.y, this.w, this.w);
        if (this.neighborCount > 0) {
          fill(0);
          textAlign(CENTER);
          textSize(16);
          text(this.neighborCount, this.x + this.w / 2, this.y + this.w / 1.5);
        }
      }
    } else if (this.flagged) {
      fill(255, 0, 0);
      triangle(
        this.x + this.w / 2, this.y + 5,
        this.x + 5, this.y + this.w - 5,
        this.x + this.w - 5, this.y + this.w - 5
      );
    }

    if (gameOver) {
      // Draw "Try Again" button
      fill(0, 150, 255);
      rect(width / 2 - 60, 430, 120, 30, 5);
      fill(255);
      textAlign(CENTER, CENTER);
      textSize(16);
      text("Try Again", width / 2, 445);
    }
  }

  countMines() {
    if (this.mine) {
      this.neighborCount = -1;
      return;
    }
    let total = 0;
    for (let xoff = -1; xoff <= 1; xoff++) {
      for (let yoff = -1; yoff <= 1; yoff++) {
        let i = this.i + xoff;
        let j = this.j + yoff;
        if (i > -1 && i < cols && j > -1 && j < rows) {
          let neighbor = grid[i][j];
          if (neighbor.mine) {
            total++;
          }
        }
      }
    }
    this.neighborCount = total;
  }

  reveal() {
    this.revealed = true;
    if (this.neighborCount === 0 && !this.mine) {
      for (let xoff = -1; xoff <= 1; xoff++) {
        for (let yoff = -1; yoff <= 1; yoff++) {
          let i = this.i + xoff;
          let j = this.j + yoff;
          if (i > -1 && i < cols && j > -1 && j < rows) {
            let neighbor = grid[i][j];
            if (!neighbor.revealed) {
              neighbor.reveal();
            }
          }
        }
      }
    }
  }

  toggleFlag() {
    if (!this.revealed) {
      this.flagged = !this.flagged;
    }
  }
}