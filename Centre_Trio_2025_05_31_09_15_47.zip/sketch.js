function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("WHITE");
  rect(100, 150, 200, 100)
  ellipse(200,200, 100, 100);
  triangle(150, 250, 200, 150, 250, 250)
}