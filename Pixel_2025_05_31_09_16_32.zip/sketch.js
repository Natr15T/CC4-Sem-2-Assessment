let img;

function preload() {
  // Load the image (you can replace this with your own image)
  img = loadImage('colorization.jpg');
}

function setup() {
  createCanvas(img.width, img.height);
  image(img, 0, 0);
  loadPixels();         // Load the canvas pixels
  img.loadPixels();     // Load the image's pixel data

  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      let index = (x + y * img.width) * 4;
      let r = img.pixels[index];
      let g = img.pixels[index + 1];
      let b = img.pixels[index + 2];

      // Convert to grayscale
      let avg = (r + g + b) / 3;

      pixels[index] = avg;
      pixels[index + 1] = avg;
      pixels[index + 2] = avg;
      pixels[index + 3] = 255; // Keep alpha full
    }
  }

  updatePixels(); // Apply the modified pixel array to the canvas
}
