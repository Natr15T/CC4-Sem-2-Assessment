function setup() {
  createCanvas(400, 400);
  noStroke();
  let size = 50;

  for (let x = 0; x < width; x += size) {
    for (let y = 0; y < height; y += size) {
      if ((x + y) % (size * 2) === 0) {
        fill(0);
      } else {
        fill(255);
      }
      rect(x, y, size, size);
    }
  }
}
