let mask;

function setup() {
  createCanvas(500, 500);
  

  mask = createGraphics(500, 500);


  mask.fill(300, 50, 0);
  mask.noStroke();
  mask.rect(100, 150, 300, 200);//Red Box


  mask.erase();
  mask.textSize(100);
  mask.textAlign(CENTER, CENTER);
  mask.text("Hello", 250, 250);
  mask.noErase();
}

function draw() {
  
  background(0);
  
  fill(0, 0, 200);
  noStroke();
  ellipse(250, 250, 170, 170);
  
  image(mask, 0, 0);
}